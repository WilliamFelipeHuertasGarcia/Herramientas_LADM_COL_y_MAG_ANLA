import os
import sys

from .reglas import Validadores

import psycopg2
import psycopg2.errorcodes
from psycopg2 import OperationalError


def reportes(hostt, puerto, usuario, contra, nombre_db, esquema, ruta):
    try:
        conexion = psycopg2.connect(
            database= str(nombre_db),
            user=str(usuario),
            password=str(contra),
            host=str(hostt),
            port=str(puerto)
        )

        # permite que cada consulta que se ejecute se confirme automaticamente
        conexion.autocommit = True

        # Crear una instancia del cursor para crear la base de datos
        cursor = conexion.cursor()
        
        # -- Consulta validaciones 01 a 011
        try:
            consul_01a011 = f"SELECT t_id, numero_predial, condicion_predio FROM {esquema}.lc_predio"
            cursor.execute(consul_01a011)

            lt_val_01a011 = []
            for row in cursor:
                lt_val_01a011.append(row)

        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 01 a 011\n{e}')
        
        
        # -- Consulta validaciones 012 a 015
        try:
            consul_012a015 = f"SELECT t_id, tiene_fmi, codigo_orip, matricula_inmobiliaria FROM {esquema}.lc_predio"
            cursor.execute(consul_012a015)

            lt_val_012a015 = []
            for row in cursor:
                lt_val_012a015.append(row)

        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 012 a 015\n{e}')

        # -- Consulta validaciones 016 a 017
        try:
            consul_016a017 = f"SELECT t_id FROM {esquema}.lc_predio WHERE destinacion_economica = 418 OR destinacion_economica = 419 OR destinacion_economica = 420"
            cursor.execute(consul_016a017)

            dest_eco = []
            a = 0
            for row in cursor:
                dest_eco.append(row)

            dest_eco = Validadores.ajusta_consulta(dest_eco)

            consul_016a017 = f"SELECT t_id, ue_lc_construccion, ue_lc_unidadconstruccion, baunit FROM {esquema}.col_uebaunit WHERE baunit IN ({dest_eco})"
            cursor.execute(consul_016a017)

            lt_val_016a017 = []
            for row in cursor:
                lt_val_016a017.append(row)

        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 016 a 017\n{e}')

        # -- Consulta validaciones 018
        try:
            consul_018 = f"SELECT t_id FROM {esquema}.lc_predio WHERE destinacion_economica = 405 OR destinacion_economica = 407 OR destinacion_economica = 409 " \
            "OR destinacion_economica = 410 OR destinacion_economica = 416 OR destinacion_economica = 422"
            cursor.execute(consul_018)

            dest_eco = []
            a = 0
            for row in cursor:
                dest_eco.append(row)

            dest_eco = Validadores.ajusta_consulta(dest_eco)

            consul_018 = f"SELECT t_id, ue_lc_construccion, ue_lc_unidadconstruccion, baunit FROM {esquema}.col_uebaunit WHERE baunit IN ({dest_eco})"
            cursor.execute(consul_018)

            lt_val_018 = []
            for i in cursor:
                lt_val_018.append(i)
        
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 018\n{e}')

        # -- Consulta Validaciones 019
        try: 
            consu_019 = f"SELECT t_id, lc_construccion FROM {esquema}.lc_unidadconstruccion"
            cursor.execute(consu_019)

            lt_val_019 = []
            for i in cursor:
                lt_val_019.append(i)

        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 019\n{e}')
        
        # -- Consulta Validaciones 020
        try:
            consul_020 = f"SELECT lc_construccion FROM {esquema}.lc_unidadconstruccion"
            cursor.execute(consul_020)

            lt_val_020_1 = []
            for i in cursor:
                lt_val_020_1.append(i[0])

            consul_020 = f"SELECT t_id FROM {esquema}.lc_construccion"
            cursor.execute(consul_020)

            lt_val_020_2 = []
            for i in cursor:
                lt_val_020_2.append(i[0])
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 020\n{e}')

        # -- Consulta Validaciones 021
        try:
            consul_021 = f"SELECT t_id, numero_predial, departamento, municipio, clase_suelo FROM {esquema}.lc_predio"
            cursor.execute(consul_021)

            lt_val_021 = []
            for i in cursor:
                lt_val_021.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 021\n{e}')

        # -- Consulta validaciones 022
        try:
            consul_022 = f"""SELECT da.t_id, da.tiene_area_registral, da.area_registral_m2, da.lc_predio,p.tiene_fmi
            FROM {esquema}.lc_datosadicionaleslevantamientocatastral AS da left join {esquema}.lc_predio AS p ON (da.lc_predio=p.t_id)"""
            cursor.execute(consul_022)

            lt_val_022 = []
            for i in cursor:
                lt_val_022.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 022\n{e}')

        # -- Consulta validaciones 023
        try:
            consul_023 = f"""SELECT uc.t_id, uc.lc_caracteristicasunidadconstruccion, cuc.tipo_construccion, cuc.tipo_unidad_construccion, cuc.uso
            FROM {esquema}.lc_unidadconstruccion AS uc
            LEFT JOIN
            {esquema}.lc_caracteristicasunidadconstruccion AS cuc
            ON uc.lc_caracteristicasunidadconstruccion = cuc.t_id;"""

            cursor.execute(consul_023)

            lt_val_023 = []
            for i in cursor:
                lt_val_023.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 023\n{e}')

        # -- Consulta validaciones 024 a 025
        try:
            consul_024a025 = f"""SELECT t_id, tipo_documento_quien_atendio, primer_nombre_quien_atendio, primer_apellido_quien_atendio,
            celular, correo_electronico, autoriza_notificaciones
            FROM {esquema}.lc_contactovisita"""

            cursor.execute(consul_024a025)

            lt_val_024 = []
            lt_val_025 = []
            for i in cursor:
                lt_val_024.append([i[0], i[1]])
                lt_val_025.append([i[0], i[6], i[4], i[5]])
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 024 a 025\n{e}')

        # -- Consulta validaciones 026 a 029
        try:
            consul_026a29 = f"""SELECT d.t_id, d.tipo, d.fraccion_derecho, d.fecha_inicio_tenencia, d.unidad,
            p.tiene_fmi, p.matricula_inmobiliaria, p.tipo, p.numero_predial FROM {esquema}.lc_derecho AS d
            LEFT JOIN
            {esquema}.lc_predio AS p
            ON d.unidad = p.t_id"""
            cursor.execute(consul_026a29)

            lt_val_026a029 = []
            for i in cursor:
                lt_val_026a029.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 026 a 029\n{e}')

        # -- Consulta validaciones 030
        try:
            consul_030 = f"""SELECT d.t_id, dalc.t_id, d.unidad, d.fecha_inicio_tenencia, dalc.fecha_visita_predial
            FROM {esquema}.lc_derecho AS d
            LEFT JOIN
            {esquema}.lc_datosadicionaleslevantamientocatastral AS dalc
            ON d.unidad = dalc.lc_predio"""

            cursor.execute(consul_030)

            lt_val_030 =[]
            for i in cursor:
                lt_val_030.append(i)

        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 030\n{e}') 

        # -- Consulta validaciones 031 a 033
        try:
            consul_031a033 = f"""
            SELECT t_id, tipo,tipo_documento, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, sexo, razon_social
            FROM {esquema}.lc_interesado
            """
            cursor.execute(consul_031a033)

            lt_val_031a33 = []
            for i in cursor:
                lt_val_031a33.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 031 a 033\n{e}') 

        # -- Consulta validaciones 034
        try:
            consul_034 = f"""SELECT p.t_id, d.t_id, d.interesado_lc_interesado, d.interesado_lc_agrupacioninteresados  FROM {esquema}.lc_derecho as d
            RIGHT JOIN 
            {esquema}.lc_predio as p
            ON d.unidad = p.t_id"""
            cursor.execute(consul_034)

            lt_val_034 = []
            for i in cursor:
                lt_val_034.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 034\n{e}') 


        # -- Consulta validaciones 035
        try:
            consul_035 = f"""SELECT pu.t_id, pu.condicion_predio, pu.ue_lc_unidadconstruccion, pu.lc_caracteristicasunidadconstruccion, cuc.tipo_unidad_construccion ,cuc.uso
            FROM (SELECT pu.t_id, pu.condicion_predio, pu.ue_lc_unidadconstruccion, uc.lc_caracteristicasunidadconstruccion
            FROM (SELECT p.t_id, p.condicion_predio, b.ue_lc_unidadconstruccion FROM
            (SELECT t_id, condicion_predio FROM {esquema}.lc_predio --
            WHERE condicion_predio IN (269, 271)) AS p
            LEFT JOIN
            {esquema}.col_uebaunit as b
            ON p.t_id = b.baunit
            WHERE b.ue_lc_unidadconstruccion IS NOT NULL) as pu
            LEFT JOIN
            {esquema}.lc_unidadconstruccion AS uc
            ON pu.ue_lc_unidadconstruccion = uc.t_id) AS pu
            LEFT JOIN
            {esquema}.lc_caracteristicasunidadconstruccion AS cuc
            ON pu.lc_caracteristicasunidadconstruccion = cuc.t_id"""
            cursor.execute(consul_035)

            lt_val_035 = []
            for i in cursor:
                lt_val_035.append(i)

        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 035\n{e}') 


        # -- Consultas validaciones 036
        try:
            consul_036 = f"""SELECT pu.t_id, pu.condicion_predio, pu.ue_lc_unidadconstruccion, pu.lc_caracteristicasunidadconstruccion, cuc.tipo_unidad_construccion ,cuc.uso
                    FROM (SELECT pu.t_id, pu.condicion_predio, pu.ue_lc_unidadconstruccion, uc.lc_caracteristicasunidadconstruccion
                    FROM (SELECT p.t_id, p.condicion_predio, b.ue_lc_unidadconstruccion FROM
                    (SELECT t_id, condicion_predio FROM {esquema}.lc_predio --
                    WHERE condicion_predio NOT IN (269, 271, 268, 270)) AS p
                    LEFT JOIN
                    {esquema}.col_uebaunit as b
                    ON p.t_id = b.baunit
                    WHERE b.ue_lc_unidadconstruccion IS NOT NULL) as pu
                    LEFT JOIN
                    {esquema}.lc_unidadconstruccion AS uc
                    ON pu.ue_lc_unidadconstruccion = uc.t_id) AS pu
                    LEFT JOIN
                    {esquema}.lc_caracteristicasunidadconstruccion AS cuc
                    ON pu.lc_caracteristicasunidadconstruccion = cuc.t_id"""
            cursor.execute(consul_036)

            lt_val_036 = []
            for i in cursor:
                lt_val_036.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 036\n{e}') 

        # -- Consulta validaciones 037
        try:
            consul_037 = f"""SELECT t_id, total_locales, uso FROM {esquema}.lc_caracteristicasunidadconstruccion"""
            cursor.execute(consul_037)

            lt_val_037 = []
            for i in cursor:
                lt_val_037.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 037\n{e}') 

        # -- Consultas validaciones 038
        try:
            consul_038_01 = f"""SELECT t_id, planta_ubicacion, lc_construccion FROM {esquema}.lc_unidadconstruccion"""
            cursor.execute(consul_038_01)

            lt_val_038_01 = []
            for i in cursor:
                lt_val_038_01.append(i)

            consul_038_02 = f"""SELECT lc_construccion, MAX(planta_ubicacion) FROM {esquema}.lc_unidadconstruccion GROUP BY lc_construccion"""
            cursor.execute(consul_038_02)

            lt_val_038_02 = []
            for i in cursor:
                lt_val_038_02.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 038\n{e}') 
        
        # -- Consultas validaciones 039 a 041
        try:
            consul_039a041 = f"""SELECT c.t_id, c.numero_pisos, c.area_construccion, c.altura,
            uc.uc_totp, uc.uc_totarea, uc.uc_totalt
            FROM {esquema}.lc_construccion AS c
            LEFT JOIN
            (SELECT lc_construccion, max(planta_ubicacion) AS uc_totp, sum(area_construida) AS uc_totarea, sum(altura) AS uc_totalt
            FROM {esquema}.lc_unidadconstruccion
            GROUP BY lc_construccion) AS uc
            ON c.t_id = uc.lc_construccion"""
            cursor.execute(consul_039a041)

            lt_val_039a041 = []
            for i in cursor:
                lt_val_039a041.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 039 a 041\n{e}') 

        # -- Consultas validaciones 042
        try:
            consul_042 = f"""SELECT cuc.t_id, cuc.uso, tc.t_id, tc.tipo_tipologia, tc.cual FROM {esquema}.lc_caracteristicasunidadconstruccion AS cuc
            RIGHT JOIN 
            {esquema}.lc_tipologiaconstruccion tc
            ON cuc.t_id = tc.lc_unidad_construccion"""
            cursor.execute(consul_042)

            lt_val_042 = []

            for i in cursor:
                lt_val_042.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 042\n{e}') 
        
        # -- Consultas validaciones 043
        try:
            consul_043 = f"""SELECT cuc.t_id, cuc.uso, cnc.t_id, cnc.tipo_anexo
            FROM {esquema}.lc_caracteristicasunidadconstruccion AS cuc
            RIGHT JOIN
            {esquema}.lc_calificacionnoconvencional cnc
            ON cuc.t_id = cnc.lc_unidad_construccion"""
            cursor.execute(consul_043)

            lt_val_043 = []
            for i in cursor:
                lt_val_043.append(i)
        except Exception as e:
            print('Se genero un error al ejecutar y/o crear la lista de la consulta 043\n{e}') 

        #-- Cierra conexion
        cursor.close()
        conexion.close()

        # -- 
        Validadores.validacion_001a010(lt_val_01a011, ruta)
        Validadores.validacion_011(lt_val_01a011, ruta)
        Validadores.validacion_012(lt_val_012a015, ruta)
        Validadores.validacion_013(lt_val_012a015, ruta)
        Validadores.validacion_014(lt_val_012a015, ruta)
        Validadores.validacion_015(lt_val_012a015, ruta)
        Validadores.validacion_016(lt_val_016a017, ruta)
        Validadores.validacion_017(lt_val_016a017, ruta)
        Validadores.validacion_018(lt_val_018, ruta)
        Validadores.validacion_019(lt_val_019, ruta)
        Validadores.validacion_020(lt_val_020_1, lt_val_020_2, ruta)
        Validadores.validacion_021(lt_val_021, ruta)
        Validadores.validacion_022(lt_val_022, ruta)
        Validadores.validacion_023(lt_val_023, ruta)
        Validadores.validacion_024(lt_val_024, ruta)
        Validadores.validacion_025(lt_val_025, ruta)
        Validadores.validacion_026(lt_val_026a029, ruta)
        Validadores.validacion_027(lt_val_026a029, ruta)
        Validadores.validacion_028(lt_val_026a029, ruta)
        Validadores.validacion_029(lt_val_026a029, ruta)
        Validadores.validacion_030(lt_val_030, ruta)
        Validadores.validacion_031(lt_val_031a33, ruta)
        Validadores.validacion_032(lt_val_031a33, ruta)
        Validadores.validacion_033(lt_val_031a33, ruta)
        Validadores.validacion_034(lt_val_034, ruta)
        Validadores.validacion_035(lt_val_035, ruta)
        Validadores.validacion_036(lt_val_036, ruta)
        Validadores.validacion_037(lt_val_037, ruta)
        Validadores.validacion_038(lt_val_038_01, lt_val_038_02, ruta)
        Validadores.validacion_039(lt_val_039a041, ruta)
        Validadores.validacion_040(lt_val_039a041, ruta)
        Validadores.validacion_041(lt_val_039a041, ruta)
        Validadores.validacion_042(lt_val_042, ruta)
        Validadores.validacion_043(lt_val_043, ruta)





    except Exception as e:
        print(e)

        
        
