import xlsxwriter
import os
import re


def ajusta_consulta(consulta):
    str_consulta = str(consulta)
    str_consulta = str_consulta.replace('[', '')
    str_consulta = str_consulta.replace(']', '')
    str_consulta = str_consulta.replace('(', '')
    str_consulta = str_consulta.replace(',)', '')

    return str_consulta

def excel(lt, nomb, tab, val, ruta, num_enc=None):
    ruta_completa = os.path.join(ruta, f'{nomb}.xlsx')
    workbook = xlsxwriter.Workbook(ruta_completa)
    worksheet = workbook.add_worksheet()

    encf = workbook.add_format({'bold': True,
                               'align': 'center',
                               'valign': 'vcenter'})
    celf = workbook.add_format({'align': 'left',
                               'valign': 'vcenter',
                               'border': 1,
                               'border_color': 'black'})

    if val == '001a010':
        enc = ['t_id', 'condicion_predio', 'numero_predial', 'Observacion']
    elif val == '011':
        enc = ['t_id(01)', 't_id(02)', 'numero_predial', 'Observacion']
    elif val == '012':
        enc = ['t_id', 'tiene_fmi', 'codifo_orip', 'matricula', 'Observacion']
    elif val == '013':
        enc = ['t_id(01)', 't_id(02)', 'matricula', 'Observacion']
    elif val == '014':
        enc = ['t_id', 'matricula', 'Observacion']
    elif val == '015':
        enc = ['t_id', 'codigo_orip', 'Observacion']
    elif val == '016':
        enc = ['t_id(lc_predio)', 'Observacion']
        for i in range(num_enc - 2):
            enc.insert(1, f'lc_construccion(0{i+1})')
    elif val == '017':
        enc = ['t_id(lc_predio)', 'Observacion']
        for i in range(num_enc - 2):
            enc.insert(1, f'lc_unidadconstruccion(0{i + 1})')
    elif val == '018':
        enc = ['t_id(lc_predio)', 'Observacion']
    elif val == '019':
        enc = ['t_id(lc_unidadconstruccion)', 'Observacion']
    elif val == '020':
        enc = ['t_id(lc_construccion)', 'Observacion']
    elif val == '021':
        enc = ['t_id', 'numero_predial', 'departamento', 'municipio', 'clase_suelo', 'Observacion']
    elif val == '022':
        enc = ['t_id(lc_datosadicionales)', 'tiene_area_registral', 'area_registral', 'lc_predio', 'tiene_fmi', 'Observacion']
    elif val == '023':
        enc = ['t_id(lc_unidadconstruccion)', 't_id(lc_caracteristicasunidadconstruccion)', 'tipo_construccion', 'tipo_unidad_construccion', 'Uso', 'Observacion']
    elif val == '024':
        enc = ['t_id', 'tipo_documento', 'Observacion']
    elif val == '025':
        enc = ['t_id', 'Autoriza_notificacion', 'Celular', 'Correo', 'Observacion']
    elif val == '026':
        enc = ['t_id', 'fecha_inicio_tenencia', 'Observacion']
    elif val == '027':
        enc = ['t_id(lc_derecho)', 't_id(lc_predio)', 'tipo_derecho', 'numero_predial', 'Observacion']
    elif val == '028':
        enc = ['t_id(lc_derecho)', 't_id(lc_predio)', 'Tipo_Predio', 'tipo_derecho', 'matricula', 'Observacion']
    elif val == '029':
        enc = ['t_id(lc_derecho)', 't_id(lc_predio)', 'tipo_derecho', 'Tipo_Predio', 'Observacion']
    elif val == '030':
        enc = ['t_id(lc_derecho)', 't_id(lc_datosAdicionalesLevCatas)', 't_id(lc_predio)', 'Fecha_inicio_tenencia', 'Fecha_visita_predial', 'Observacion']
    elif val == '031':
        enc = ['t_id', 'tipo_interesado', 'tipo_documento', 'Primer_nombre', 'Segundo_Nombre', 'Primer_Apellido', 'Segundo_Apellido', 'Sexo', 'Razon_social', 'Observacion']
    elif val == '032':
        enc = ['t_id', 'tipo_interesado', 'Sexo', 'Observacion']
    elif val == '033':
        enc = ['t_id', 'tipo_interesado', 'Tipo_documento', 'Observacion']
    elif val == '034':
        enc = ['t_id(lc_predio)', 't_id(lc_derecho)', 't_id(lc_interesado)', 't_id(lc_agrupacionInteresado)', 'Observacion']
    elif val == '035':
        enc = ['t_id(lc_predio)', 'condicion_predio', 't_id(lc_unidadConstruccion)', 't_id(lc_caracteristicaunidadconstruccion)', 'tipo_unidad_construccion', 'uso', 'Observacion']
    elif val == '036':
        enc = ['t_id(lc_predio)', 'condicion_predio', 't_id(lc_unidadConstruccion)', 't_id(lc_caracteristicaunidadconstruccion)', 'tipo_unidad_construccion', 'uso', 'Observacion']
    elif val == '037':
        enc = ['t_id', 'Total_locales', 'Uso', 'Observacion']
    elif val == '038':
        enc = ['lc_construccion', 'total_plantas_registradas', 'Observacion']
    elif val == '039':
        enc = ['t_id(lc_construccion)', 'numero_pisos(lc_construccion)', 'numero_pisos(unidades)', 'Observacion']
    elif val == '040':
        enc = ['t_id(lc_construccion)', 'area(lc_construccion)', 'area(unidades)', 'Observacion']
    elif val == '041':
        enc = ['t_id(lc_construccion)', 'Altura(lc_construccion)', 'Altura(unidades)', 'Observacion']
    elif val == '042':
        enc = ['t_id(lc_caracteristicaunidadconstruccion)', 'uso', 't_id(lc_tipologiaconstruccion)', 'tipo_tipologia', 'cual', 'Observacion']
    elif val == '043':
        enc = ['t_id(lc_caracteristicaunidadconstruccion)', 'uso', 't_id(lc_calificacionnoconvencional)', 'tipo_anexo', 'Observacion']
    else:
        enc = ['']

    worksheet.merge_range('A1:D1', f'Revisar las tablas {tab}', encf)

    for col_num, enc in enumerate(enc):
        worksheet.write(1, col_num, enc, encf)

    for row_num, regis, in enumerate(lt, start=2):
        for col_num, valor in enumerate(regis):
            worksheet.write(row_num, col_num, valor, celf)

    for col_num, enc in enumerate(enc):
        worksheet.set_column(col_num, col_num, len(enc) + 5)

    workbook.close()

    #ruta_completa = os.path.abspath(f'{nomb}.xlsx')
    #print("El archivo de Excel se ha creado en la siguiente ruta:\n", ruta_completa)

#Reglas de consistencia del numero predial nacional
def validacion_001a010(lt, ruta):
    r = [[], [], [], [], [], [], [], [], [], [], []]
    c = [0]*11
    archivos = {}
    for i in lt:
        cp = i[1]
        if i[2] == 267:
            if cp[21:] == '000000000':
                """b = [i[0], i[2], i[1], 'OK']
                r[0].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '001_Para NPH los digitos 22 - 30 del NPN deben ser 000000000']
                r[0].append(b)
                c[0] += 1

        elif i[2] == 268:
            if cp[21:] == '900000000':
                """b = [i[0], i[2], i[1], 'OK']
                r[1].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '002_Para PH matriz los digitos 22 - 30 del NPN deben ser 900000000']
                r[1] .append(b)
                c[1] += 1

        elif i[2] == 269:
            if cp[21] == '9' and cp[22:] != '00000000':
                """b = [i[0], i[2], i[1], 'OK']
                r[2].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '003_Para PH unidad predial el digito 22 de NPN debe ser 9 y del 23 - 30 diferente de ceros']
                r[2].append(b)
                c[2] += 1

        elif i[2] == 270:
            if cp[21:] == '800000000':
                """b = [i[0], i[2], i[1], 'OK']
                r[3].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '004_Para Condominio matriz los digitos 22 - 30 del NPN deben ser 800000000']
                r[3].append(b)
                c[3] += 1

        elif i[2] == 271:
            if cp[21:26] == '80000' and cp[26:] != '0000':
                """b = [i[0], i[2], i[1], 'OK']
                r[4].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '005_Para PH condominio unidad predial los digitos 22-26 deben ser 80000 y de 27-30 diferente ceros']
                r[4].append(b)
                c[4] += 1

        elif i[2] == 272:
            if cp[21:] == '700000000':
                """b = [i[0], i[2], i[1], 'OK']
                r[5].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '006_Para predios Parque_Cementerio_Matriz los digitos 22-30 del NPN deben ser 700000000']
                r[5].append(b)
                c[5] += 1

        elif i[2] == 273:
            if cp[21:26] == '70000' and cp[26:] != '0000':
                """b = [i[0], i[2], i[1], 'OK']
                r[6].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '007_Para Parque_Cementerio_Matriz unidad predial los digitos 22-26 deben ser 70000 y de 27-30 diferente ceros']
                r[6].append(b)
                c[6] += 1

        elif i[2] == 274:
            if cp[21:] == '400000000':
                """b = [i[0], i[2], i[1], 'OK']
                r[7].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '008_Para Vias los digitos 22-30 del NPN deben ser 400000000']
                r[7].append(b)
                c[7] += 1

        elif i[2] == 275:
            if cp[21:] == '200000000':
                """b = [i[0], i[2], i[1], 'OK']
                r[8].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '009_Para predios informales los digitos 22-30 del NPN deben ser 200000000']
                r[8].append(b)
                c[8] += 1

        elif i[2] == 276:
            if cp[21:] == '300000000':
                """b = [i[0], i[2], i[1], 'OK']
                r[9].append(b)"""
                pass
            else:
                b = [i[0], i[2], i[1], '010_Para Bienes de uso publico los digitos 22-30 del NPN deben ser 300000000']
                r[9].append(b)
                c[9] += 1

        else:
            pass
    for i in range(len(r)):
        if c[i] != 0:
            archivos[r[i][0][3]] = r[i]
            print(f"Se presentaron _{c[i]}_ inconsistencias del tipo:\n{r[i][0][3]}\n")
            try:
                excel(archivos[r[i][0][3]], r[i][0][3], 'lc_predio', '001a010', ruta)
            except Exception as e:
                print(f"No se pudo generar el archivo Excel con el reporte,\n"\
                      f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n"\
                      f"y que tenga instalada la libreria xlsxwriter de python\n{e}")
        else:
            pass

def validacion_011(lt, ruta):
    cp = []
    for i in lt:
        cp.append(i[1])
    if len(cp) == len(set(cp)):
        pass
    else:
        b = []
        for i in range(len(lt)):
            a = 0
            for j in range(i + 1, len(lt)):
                if lt[i][1] == lt[j][1] and lt[i][0] != lt[j][0]:
                    b.append([lt[i][0], lt[j][0], lt[i][1], '011_Mas de un registro con el mismo numero predial'])

        try:
            if len(b) > 0:
                print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n011_Mas de un registro con el mismo numero predial \n")
                excel(b, '011_Mas de un registro con el mismo numero predial', 'lc_predio', '011', ruta)
            else:
                print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n011_Mas de un registro con el mismo numero predial \n")
        except Exception as e:
            print(f"No se pudo generar el archivo Excel con el reporte,\n" \
                  f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
                  f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

# Reglas FMI
def validacion_012(lt, ruta):
    b = []
    for i in lt:
        if i[1] == False and i[2] == None and i[3] == None:
            pass
        elif i[1] == False and (i[2] != None or i[3] != None):
            r = list(i)
            r.append('012_Si cuenta o No con FMI, el circulo registral y la matricula deben ser consistentes')
            b.append(r)
        elif i[1] == True and i[3] == None:
            r = list(i)
            r.append('012_Si cuenta o No con FMI, el circulo registral y la matricula deben ser consistentes')
            b.append(r)
        else:
            pass
    

    try:
        if len(b) > 0:
            print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n012_Si cuenta o No con FMI, el circulo registral y la matricula deben ser consistentes\n")
            excel(b, '012_Si cuenta o No con FMI, el circulo registral y la matricula deben ser consistentes', 'lc_predio',
                '012', ruta)
        else:
            print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n012_Si cuenta o No con FMI, el circulo registral y la matricula deben ser consistentes\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_013(lt, ruta):
    fmi = []
    for i in lt:
        fmi.append(i[3])
    if len(fmi) == len(set(fmi)):
        pass
    else:
        b = []
        for i in range(len(lt)):
            a = 0
            for j in range(i + 1, len(lt)):
                if lt[i][3] == lt[j][3] and (lt[i][3] != None or lt[j][3] != None):
                    b.append([lt[i][0], lt[j][0], lt[i][3], '013_No deben haber fmi duplicados'])
        try:
            if len(b) > 0:
                print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n013_No deben haber fmi duplicados \n")
                excel(b, '013_No deben haber fmi duplicados', 'lc_predio', '013', ruta)
            else:
                print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n013_No deben haber fmi duplicados \n")
        except Exception as e:
            print(f"No se pudo generar el archivo Excel con el reporte,\n" \
                  f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
                  f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_014(lt, ruta):
    b = []
    for i in lt:
        if i[1] == True and (len(i[3]) <= 0 or len(i[3]) > 7):
            b.append([i[0], i[3], '014_La matricula debe tener entre 1 y 7 caracteres(Opc matricula sis. ant)'])

    try:
        if len(b) > 0:
            print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n014_La matricula debe tener entre 1 y 7 caracteres \n")
            excel(b, '014_La matricula debe tener entre 1 y 7 caracteres', 'lc_predio', '014', ruta)
        else:
            print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n014_La matricula debe tener entre 1 y 7 caracteres \n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_015(lt, ruta):
    b = []
    for i in lt:
        if i[2] != None and len(i[2]) != 3:
            b.append([i[0], i[2], '015_El circulo registral debe tener 3 caracteres(Opc matricula sis. ant)'])

    try:
        if len(b) > 0:
            print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n015_El circulo registral debe tener 3 caracteres \n")
            excel(b, '015_El circulo registral debe tener 3 caracteres', 'lc_predio', '015', ruta)
        else:
            print(f"Se presentaron _{len(b)}_ inconsistencias del tipo:\n015_El circulo registral debe tener 3 caracteres \n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n"\
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n"\
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_016(lt, ruta):
    b = {}
    c = 0
    for i in lt:
        if i[1] != None and i[3] not in b:
            b[i[3]] = [i[3]]
            b[i[3]].extend([i[1]])
        elif i[1] != None and i[3] in b:
            b[i[3]].extend([i[1]])

    m = []
    for k in b:
        b[k].extend(['016_los predios con destinacion economica lote No deben tener construcciones asociadas'])
        m.append(b[k])

    for j in b:
        if c < len(b[j]):
            c = len(b[j])
        else:
            pass

    try:
        if len(m) > 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n016_los predios con destinacion economica lote No deben tener construcciones asociadas\n")
            excel(m, '016_los predios con destinacion economica lote No deben tener construcciones asociadas',
                '(lc_predio, lc_construccion, col_uebaunit)', '016', ruta, c)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n016_los predios con destinacion economica lote No deben tener construcciones asociadas\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_017(lt, ruta):
    b = {}
    c = 0
    for i in lt:
        if i[2] != None and i[3] not in b:
            b[i[3]] = [i[3]]
            b[i[3]].extend([i[2]])
        elif i[2] != None and i[3] in b:
            b[i[3]].extend([i[2]])
    m = []

    for k in b:
        b[k].extend(['017_los predios con destinacion economica lote No deben tener unidades de construccion asociadas'])
        m.append(b[k])

    for j in b:
        if c < len(b[j]):
            c = len(b[j])
        else:
            pass
    try:
        if len(m) > 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n017_los predios con destinacion economica lote No deben tener unidades de construccion asociadas\n")
            excel(m, '017_los predios con destinacion economica lote No deben tener unidades de construccion asociadas',
                '(lc_predio, lc_construccion, col_uebaunit)', '017', ruta, c)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n017_los predios con destinacion economica lote No deben tener unidades de construccion asociadas\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_018(lt, ruta):
    b = {}
    for i in lt:
        if i[3] not in b:
            b[i[3]] = [i[3],
                       '018_Los predios con destinacion economica Comercial, Educativo, Habitacional, Industrial, Institucional o Recreacional deben tener al menos una construccion asociada']
        else:
            pass
    d = {}
    for j in lt:
        if j[1] != None and j[3] not in d:
            d[j[3]] = j[3]
        else:
            pass
    for k in d:
        del (b[k])

    m = []
    for n in b:
        m.append(b[n])

    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n018_Los predios con destinacion economica Comercial, Educativo, Habitacional, Industrial, Institucional o Recreacional deben tener al menos una construccion asociada\n")
            excel(m, '018_Los predios con destinacion economica Comercial, Educativo, Habitacional, Industrial, Institucional o Recreacional deben tener al menos una construccion asociada', 'lc_predio, lc_construccion, col_uebaunit', '018', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n018_Los predios con destinacion economica Comercial, Educativo, Habitacional, Industrial, Institucional o Recreacional deben tener al menos una construccion asociada\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_019(lt, ruta):
    a = []
    for i in lt:
        if i[1] == None or i[1] == '':
            a.append(i)
    try:
        if len(a) != 0:
            print(f"Se presentaron _{len(a)}_ inconsistencias del tipo:\n019_Todas las unidades de construccion deben estar asocidas a una construccion\n")
            excel(a, '019_Todas las unidades de construccion deben estar asocidas a una construccion', 'lc_unidadconstruccion, lc_construccion', '019', ruta)
        else:
            print(f"Se presentaron _{len(a)}_ inconsistencias del tipo:\n019_Todas las unidades de construccion deben estar asocidas a una construccion\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_020(lt1, lt2, ruta):
    lt = []
    for i in lt2:
        if i not in lt1:
            lt.append([i, '020_todas las construcciones deben tener almenos una construccion asociada.'])
        else:
            pass
    try:
        if len(lt) != 0:
            print(f"Se presentaron _{len(lt)}_ inconsistencias del tipo:\n020_todas las construcciones deben tener almenos una construccion asociada.\n")
            excel(lt, '020_todas las construcciones deben tener almenos una construccion asociada.', 'lc_construccion, lc_unidadconstruccion', '020', ruta)
        else:
            print(f"Se presentaron _{len(lt)}_ inconsistencias del tipo:\n020_todas las construcciones deben tener almenos una construccion asociada.\n ")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_021(lt, ruta):
    a = []
    for j in lt:
        j = list(j)
        if j[1][:2] == j[2] and j[1][2:5] == j[3]:
            if j[1][5:7] == '01':
                if j[4] == 12 or j[4] == 14:
                    pass
                else:
                    j.append('021_el NPN debe ser consistente con clase_suelo')
                    a.append(j)
            elif j[1][5:7] == '02':
                if j[4] == 13:
                    pass
                else:
                    j.append('021_el NPN debe ser consistente con clase_suelo')
                    a.append(j)
            else:
                j.append('021_el NPN debe ser consistente con clase_suelo')
                a.append(j)
        else:
            j.append('021_el NPN debe ser consistente con el departamento, municipio y de clase_suelo')
            a.append(j)
    try:
        if len(a) != 0:
            print(f"Se presentaron _{len(a)}_ inconsistencias del tipo:\n021_el NPN debe ser consistente con clase_suelo\n")
            excel(a, '021_el NPN debe ser consistente con clase_suelo', 'lc_predio', '021', ruta)
        else:
            print(f"Se presentaron _{len(a)}_ inconsistencias del tipo:\n021_el NPN debe ser consistente con clase_suelo\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_022(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if (i[4] == False and i[1] == True) or (i[4] == False and i[2] != None):
            i.append(
                '022_Debe haber correspondencia entre tiene_fmi(lc_predio) y tiene_area_regis(lc_datosadicionaleslevcatastral), Si No tiene_fmi area registral debe ser Nula')
            m.append(i)
        elif i[1] == False and i[2] != None:
            i.append('022_Si No tiene area registral, area registral debe ser Nula')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n022_Debe haber correspondencia entre tiene_fmi y tiene_area_regis, Si No tiene_fmi area registral debe ser Nula\n")
            excel(m, '022_Debe haber correspondencia entre tiene_fmi y tiene_area_regis, Si No tiene_fmi area registral debe ser Nula', 'lc_predio, lc_datosadicionaleslevcatastral', '022', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n022_Debe haber correspondencia entre tiene_fmi y tiene_area_regis, Si No tiene_fmi area registral debe ser Nula\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_023(lt, ruta):
    m = []
    uso_residencial = []
    uso_comercial = []
    uso_industrial = []
    uso_institucional = []
    uso_anexo = []
    for i in range(279, 294):
        uso_residencial.append(i)
    for i in range(294, 318):
        uso_comercial.append(i)
    for i in range(318, 323):
        uso_industrial.append(i)
    for i in range(323, 346):
        uso_institucional.append(i)
    for i in range(346, 381):
        uso_anexo.append(i)

    for i in lt:
        i = list(i)
        if i[2] == 593 and i[3] in [166, 167, 168, 169]:
            if i[3] == 166 and i[4] not in uso_residencial:
                i.append('023_Para unidad de construccion el tipo_unidad(Residencial) debe ser consistente con su uso')
                m.append(i)
            elif i[3] == 167 and i[4] not in uso_comercial:
                i.append('0023_Para unidad de construccion el tipo_unidad(Comercial) debe ser consistente con su uso')
                m.append(i)
            elif i[3] == 168 and i[4] not in uso_industrial:
                i.append('023_Para unidad de construccion el tipo_unidad(Industrial) debe ser consistente con su uso')
                m.append(i)
            elif i[3] == 169 and i[4] not in uso_institucional:
                i.append(
                    '023_Para unidad de construccion el tipo_unidad(Institucional) debe ser consistente con su uso')
                m.append(i)
        elif i[2] == 593 and i[3] not in [166, 167, 168, 169]:
            i.append(
                '023_Para unidad de construccion el tipo_construccion(Convencional) debe ser consistente con tipo_unidad_construccion')
            m.append(i)
        elif i[2] == 594 and i[3] == 170:
            if i[3] == 170 and i[4] not in uso_anexo:
                i.append('023_Para unidad de construccion el tipo_unidad(Anexo) debe ser consistente con su uso')
                m.append(i)
        elif i[2] == 594 and i[3] != 170:
            i.append(
                '023_Para unidad de construccion el tipo_construccion(No_Convencional) debe ser consistente con tipo_unidad_construccion')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n023_Para UC el tipo_construccion debe ser consistente con tipo_unidad y Uso\n")
            excel(m, '023_Para UC el tipo_construccion debe ser consistente con tipo_unidad y Uso', 'lc_unidadconstruccion, lc_caracteristicasunidadconstruccion', '023', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n023_Para UC el tipo_construccion debe ser consistente con tipo_unidad y Uso\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_024(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[1] in [565, 568]:
            i.append('024_Contacto visita no puede ser una persona juridica. ')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n024_Contacto visita no puede ser una persona juridica.\n")
            excel(m, '024_Contacto visita no puede ser una persona juridica.', 'lc_contactovisita', '024', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n024_Contacto visita no puede ser una persona juridica.\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_025(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[1] == True and i[2] in [None, ''] and i[3] in [None, '']:
            i.append('025_ Si contacto visita autoriza notificacion, celular y correo no pueden estar vacios')
            m.append(i)

    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n025_ Si contacto visita autoriza notificacion, celular y correo no pueden estar vacios\n")
            excel(m, '025_ Si contacto visita autoriza notificacion, celular y correo no pueden estar vacios', 'lc_contactovisita', '025', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n025_ Si contacto visita autoriza notificacion, celular y correo no pueden estar vacios\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_026(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[3] in [None, '']:
            i.append('026_La fecha de inicio tenencia debe estar diligenciada')
            m.append([i[0], i[3], i[9]])
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n026_La fecha de inicio tenencia debe estar diligenciada\n")
            excel(m, '026_La fecha de inicio tenencia debe estar diligenciada', 'lc_derecho', '026', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n026_La fecha de inicio tenencia debe estar diligenciada\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_027(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[8][21] != '2' and i[1] != 53:
            i.append('027_los predios formales deben tener asociado un derecho de tipo Dominio')
            m.append([i[0], i[4], i[1], i[8], i[9]])
        elif i[8][21] == '2' and i[1] == 53:
            i.append('027_los predios informales deben tener asociado un derecho de tipo Posesion u Ocupacion')
            m.append([i[0], i[4], i[1], i[8], i[9]])
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n027_El tipo de derecho debe ser consistente con la condicion del predio\n")
            excel(m, '027_El tipo de derecho debe ser consistente con la condicion del predio', 'lc_derecho, lc_predio', '027', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n027_El tipo de derecho debe ser consistente con la condicion del predio\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_028(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[7] == 450 and i[1] == 53 and i[6] in [None, '']:
            i.append('028_Un predio de tipo privado y con derecho de dominio debe contar con matricula')
            m.append([i[0], i[4], i[7], i[1], i[6], i[9]])
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n028_Un predio de tipo privado y con derecho de dominio debe contar con matricula\n")
            excel(m, '028_Un predio de tipo privado y con derecho de dominio debe contar con matricula', 'lc_predio, lc_derecho', '028', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n028_Un predio de tipo privado y con derecho de dominio debe contar con matricula\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_029(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[1] == 55 and i[7] != 450:
            i.append('029_los predios con derecho de Posesion deben ser Privados ')
            m.append([i[0], i[4], i[1], i[7], i[9]])
        elif i[1] == 54 and i[7] not in [445, 446, 447, 448, 449]:
            i.append('029_los predios con derecho de Ocupacion deben ser Publicos ')
            m.append([i[0], i[4], i[1], i[7], i[9]])
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n029_los predios con derecho posesion u ocupacion, deben ser privados o publicos segun corresponda.\n")
            excel(m, '029_los predios con derecho posesion u ocupacion, deben ser privados o publicos segun corresponda', 'lc_predio, lc_derecho', '029', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n029_los predios con derecho posesion u ocupacion, deben ser privados o publicos segun corresponda.\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_030(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[3] in [None, ''] or i[4] in [None, '']:
            i.append('30_El predio debe contar con fecha de inicio de tenencia y fecha de visita')
            m.append(i)
        elif i[3] > i[4]:
            i.append('30_El la fecha de inicio de tenencia debe ser menor o igual a la fecha de visita')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n030_las fechas de inicio de tenencia y de visita deben ser consistentes, y deben estar diligenciadas\n")
            excel(m, '030_las fechas de inicio de tenencia y de visita deben ser consistentes, y deben estar diligenciadas', 'lc_derecho, lc_datosAdicionalesLevantamientoCatastral', '030', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n030_las fechas de inicio de tenencia y de visita deben ser consistente, y deben estar diligenciadas\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_031(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[1] == 156 and (i[3] in [None, ''] or i[5] in [None, '']):
            i.append('031_las personas naturales no deben tener Primer nombre y apellido vacios')
            m.append(i)
        elif i[1] == 156 and i[4] not in [None, '']:
            if i[6] not in [None, '']:
                if re.search(r'\d', i[3]) or re.search(r'\d', i[4]) or re.search(r'\d', i[5]) or re.search(r'\d', i[6]):
                    i.append(
                        '031_las personas naturales no deben tener caracteres numericos en los campos nombres y/o apellidos')
                    m.append(i)
            else:
                if re.search(r'\d', i[3]) or re.search(r'\d', i[4]) or re.search(r'\d', i[5]):
                    i.append(
                        '031_las personas naturales no deben tener caracteres numericos en los campos nombres y/o apellidos')
                    m.append(i)
        elif i[1] == 156 and i[6] not in [None, '']:
            if re.search(r'\d', i[3]) or re.search(r'\d', i[5]) or re.search(r'\d', i[6]):
                i.append(
                    '031_las personas naturales no deben tener caracteres numericos en los campos nombres y/o apellidos')
                m.append(i)
        if i[1] == 157 and (i[3] != None or i[4] != None or i[5] != None or i[6] != None):
            i.append(
                '031_las personas juridicas no deben tener diligenciado los campos nombres y/o apellidos(estos deben ser NULL)')
            m.append(i)
        elif i[1] == 157 and i[8] in [None, '']:
            i.append('031_las personas juridicas deben tener diligenciado el campo razon social')
            m.append(i)
        if i[1] == 156 and i[8] not in [None, '']:
            i.append('031_las personas naturales no deben tener diligenciado el campo razon_social')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n031_las personas naturales y juridicas deben estructurar nombre o razon social de forma correcta\n")
            excel(m, '031_las personas naturales y juridicas deben estructurar nombre o razon social de forma correcta', 'lc_interesado', '031', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n031_las personas naturales y juridicas deben estructurar nombre o razon social de forma correcta\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_032(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[1] == 156 and i[7] in [None, '']:
            i.append('032_Las personas naturales deben tener diligenciado el campo sexo')
            m.append([i[0], i[1], i[7], i[9]])
        elif i[1] == 157 and i[7] not in [None, '']:
            i.append('032_Las personas juridicas No deben tener diligenciado el campo sexo')
            m.append([i[0], i[1], i[7], i[9]])

    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n032_El campo sexo debe ser consisite con el campo tipo_persona\n")
            excel(m, '032_El campo sexo debe ser consisite con el campo tipo_persona', 'lc_interesado', '032', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n032_El campo sexo debe ser consisite con el campo tipo_interesado\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_033(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[1] == 156 and i[2] in [565, 568]:
            i.append('032_Las personas naturales NO deben tener NIT o Secuencial')
            m.append([i[0], i[1], i[2], i[9]])
        elif i[1] == 157 and i[7] not in [565, 568]:
            i.append('032_Las personas juridicas Deben tener NIT o Secuencial')
            m.append([i[0], i[1], i[2], i[9]])

    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n033_El tipo de documento debe ser consistente el campo tipo_interesado\n")
            excel(m, '033_El tipo de documento debe ser consistente el campo tipo_interesado', 'lc_interesado', '033', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n033_El tipo de documento debe ser consistente el campo tipo_interesado\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n"\
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_034(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[1] in [None, '']:
            i.append('034_El predio debe contar con interesado o agrupacion de interesado')
            m.append(m)
        elif i[2] in [None, '']:
            if i[3] in [None, '']:
                i.append('034_El predio debe contar con interesado o agrupacion de interesado')
                m.append(m)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n034_Todos los predios deben tener asociado interesado o agrupacion interesado\n")
            excel(m, '034_Todos los predios deben tener asociado interesado o agrupacion interesado', 'lc_predio, lc_derecho', '034', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n034_Todos los predios deben tener asociado interesado o agrupacion interesado\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_035(lt, ruta):
    m = []
    usos_ph = [279, 286, 291, 293, 295, 297, 301, 304, 307, 310, 315, 317, 319, 321, 334]
    usos_ph_residencial = [279, 286, 291, 293]
    usos_ph_comercial = [295, 297, 301, 304, 307, 310, 315, 317]
    usos_ph_industrial = [319, 321]
    usos_ph_institucional = [334]
    for i in lt:
        i = list(i)
        if i[5] in usos_ph:
            if i[4] == 166 and i[5] not in usos_ph_residencial:
                i.append(
                    '035_las unidades de PH o Condominio de tipo Residencial deben tener usos asociados a PH_Residencial')
                m.append(i)
            elif i[4] == 167 and i[5] not in usos_ph_comercial:
                i.append(
                    '035_las unidades de PH o Condominio de tipo Comercial deben tener usos asociados a PH_Comercial')
                m.append(i)
            elif i[4] == 168 and i[5] not in usos_ph_industrial:
                i.append(
                    '035_las unidades de PH o Condominio de tipo Industrial deben tener usos asociados a PH_Industrial')
                m.append(i)
            elif i[4] == 169 and i[5] not in usos_ph_institucional:
                i.append(
                    '035_las unidades de PH o Condominio de tipo Institucional deben tener usos asociados a PH_Institucional')
                m.append(i)
        else:
            i.append('035_las unidades de PH o Condominio deben tener usos asociados a PH')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n035_las unidades de PH o Condominio deben tener usos asociados a PH\n")
            excel(m, '035_las unidades de PH o Condominio deben tener usos asociados a PH', 'lc_predio, col_uebunit, lc_unidadconstruccion, lc_caracteristicasUnidadConstruccion', '035', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n035_las unidades de PH o Condominio deben tener usos asociados a PH\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")
        
def validacion_036(lt, ruta):
    m = []
    uso_residencial = [280, 281, 282, 283, 284, 285, 287, 288, 289, 290, 292]
    uso_comercial = [294, 296, 298, 299, 300, 302, 303, 305, 306, 308, 309, 311, 312, 313, 314, 316]
    uso_industrial = [318, 320, 322]
    uso_institucional = [323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 335, 336, 337, 338, 339, 340, 341, 342,
                         343, 344, 345]
    uso_anexo = []

    for j in (346, 381):
        uso_anexo.append(j)

    for i in lt:
        i = list(i)
        if i[4] not in uso_residencial or i[4] not in uso_comercial or i[4] not in uso_industrial or i[4] not in uso_institucional or i[4] not in uso_anexo:
            if i[4] == 166 and i[5] not in uso_residencial:
                i.append('036_Las unidades NO PH de tipo Residencial deben tener usos residenciales')
                m.append(i)
            elif i[4] == 167 and i[5] not in uso_comercial:
                i.append('036_Las unidades NO PH de tipo Comercial deben tener usos comerciales')
                m.append(i)
            elif i[4] == 168 and i[5] not in uso_industrial:
                i.append('036_Las unidades NO PH de tipo Industrial deben tener usos industrial')
                m.append(i)
            elif i[4] == 169 and i[5] not in uso_institucional:
                i.append('036_Las unidades NO PH de tipo Institucional deben tener usos institucional')
                m.append(i)
            elif i[4] == 170 and i[5] not in uso_anexo:
                i.append('036_Las unidades NO PH de tipo Institucional deben tener usos institucional')
                m.append(i)
        else:
            i.append('036_Las unidades NO PH deben tener usos diferentes a PH')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n036_Las unidades NO PH deben tener usos diferentes a PH y ser consistentes\n")
            excel(m, '036_Las unidades NO PH deben tener usos diferentes a PH y ser consistentes', 'lc_predio, col_uebunit, lc_unidadconstruccion, lc_caracteristicasUnidadConstruccion', '036', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n036_Las unidades NO PH deben tener usos diferentes a PH y ser consistentes\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_037(lt, ruta):
    uso_comercial = []
    for i in range(294, 318):
        uso_comercial.append(i)
    m = []
    for i in lt:
        i = list(i)
        if i[1] > 0 and i[2] not in uso_comercial:
            i.append('037_solo deben existir locales para unidades de uso comercial')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n037_solo deben existir locales para unidades de uso comercial\n")
            excel(m, '037_solo deben existir locales para unidades de uso comercial', 'lc_predio', '037', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n037_solo deben existir locales para unidades de uso comercial\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_038(lt1, lt2, ruta):
    m = []
    for i in lt2:
        i = list(i)
        b = []
        c = 0
        for j in lt1:
            if j[2] == i[0] and j[1] not in b:
                c += 1
                b.append(c)
        if i[1] != c:
            i.append(
                '038_las unidades asociadas a una misma construccion no deben presentar salto en el campo numero de plantas')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n038_las unidades asociadas a una misma construccion no deben presentar salto en el campo numero de plantas\n")
            excel(m, '038_las unidades asociadas a una misma construccion no deben presentar salto en el campo numero de plantas', 'lc_unidadconstruccion', '038', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n038_las unidades asociadas a una misma construccion no deben presentar salto en el campo numero de plantas\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_039(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[1] != i[4]:
            m.append([i[0], i[1], i[4],
                      '039_El No. de pisos de la construccion debe ser consisitente con el No. de plantas definidas en las UC asociadas a la misma'])
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n039_El No. de pisos de la construccion debe ser consisitente con el No. de plantas definidas en las UC asociadas a la misma\n")
            excel(m, '039_El No de pisos de la construccion debe ser consisitente con el No de plantas definidas en las UC asociadas a la misma', 'lc_construccion, lc_unidadconstruccion', '039', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n039_El No. de pisos de la construccion debe ser consisitente con el No. de plantas definidas en las UC asociadas a la misma\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_040(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[2] != i[5]:
            m.append([i[0], i[2], i[5],
                      '040_El area de la construccion debe ser consisitente con la suma de areas de las UC asociadas a la misma'])
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n040_El area de la construccion debe ser consisitente con la suma de areas de las UC asociadas a la misma\n")
            excel(m, '040_El area de la construccion debe ser consisitente con la suma de areas de las UC asociadas a la misma', 'lc_construccion, lc_unidadconstruccion', '040', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n040_El area de la construccion debe ser consisitente con la suma de areas de las UC asociadas a la misma\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_041(lt, ruta):
    m = []
    for i in lt:
        i = list(i)
        if i[3] != i[6]:
            m.append([i[0], i[3], i[6],
                      '041_La altura de la construccion debe ser consisitente con la suma de alturas de las UC asociadas a la misma'])
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n041_La altura de la construccion debe ser consisitente con la suma de alturas de las UC asociadas a la misma\n")
            excel(m, '041_La altura de la construccion debe ser consisitente con la suma de alturas de las UC asociadas a la misma', 'c_construccion, lc_unidadconstruccion', '041', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n041_La altura de la construccion debe ser consisitente con la suma de alturas de las UC asociadas a la misma\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_042(lt, ruta):
    m = []
    uso_residencial = []
    uso_comercial = []
    uso_industrial = []
    uso_institucional = []
    uso_anexo = []
    for i in range(279, 294):
        uso_residencial.append(i)
    for i in range(294, 318):
        uso_comercial.append(i)
    for i in range(318, 323):
        uso_industrial.append(i)
    for i in range(323, 346):
        uso_institucional.append(i)
    for i in range(346, 381):
        uso_anexo.append(i)

    tipologia_residencial = []
    tipologia_comercial = []
    tipologia_industrial = []
    tipologia_institucional = [537]
    for i in range(513, 525):
        tipologia_residencial.append(i)
    for i in range(525, 531):
        tipologia_comercial.append(i)
    for i in range(531, 536):
        tipologia_industrial.append(i)

    for i in lt:
        i = list(i)
        if i[1] in uso_residencial and i[3] not in tipologia_residencial:
            if i[3] == 537 and i[5] in [None, '']:
                i.append('042_las unidades con usos residenciales y tipologia(otra) deben espesificar cual')
                m.append(i)
            else:
                i.append('042_las unidades con usos residenciales deben calificarse con tipologias residenciales')
                m.append(i)
        elif i[1] in uso_comercial and i[3] not in tipologia_comercial:
            if i[3] == 537 and i[5] in [None, '']:
                i.append('042_las unidades con usos comerciales y tipologia(otra) deben espesificar cual')
                m.append(i)
            else:
                i.append('042_las unidades con usos comerciales deben calificarse con tipologias comerciales')
                m.append(i)
        elif i[1] in uso_industrial and i[3] not in tipologia_industrial:
            if i[3] == 537 and i[5] in [None, '']:
                i.append('042_las unidades con usos industriales y tipologia(otra) deben espesificar cual')
                m.append(i)
            else:
                i.append('042_las unidades con usos industriales deben calificarse con tipologias industriales')
                m.append(i)
        elif i[1] in uso_institucional and i[3] not in tipologia_institucional:
            i.append('042_las unidades con usos institucionales deben calificarse con tipologias institucionales(otra)')
            m.append(i)
    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n042_las calificaciones por tipologias deben ser consistentes con el uso de la unidad de construccion \n")
            excel(m, '042_las calificaciones por tipologias deben ser consistentes con el uso de la unidad de construccion', 'lc_caracteristicasunidadconstruccion, lc_tipologiaconstruccion', '042', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n42_las calificaciones por tipologias deben ser consistentes con el uso de la unidad de construccion\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n" \
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n" \
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")

def validacion_043(lt, ruta):
    tip_enrramadas = [183, 184, 185, 186]
    tip_galpones = [187, 188, 189, 190]
    tip_establos = [191, 192, 193, 194]
    tip_cocheras = [195, 196, 197, 198]
    tip_silos = [199, 200]
    tip_piscinas = [201, 202, 203, 204]
    tip_tanques = [205, 206, 207, 208]
    tip_beneficiaderos = [209, 210, 211]
    tip_secaderos = [212, 213, 214]
    tip_kioscos = [215, 216, 217, 218]
    tip_albercas = [219, 220, 221]
    tip_corrales = [222, 223, 224, 225]
    tip_pozos = [226, 227, 228]
    tip_torres = [229]
    tip_muelles = [230, 231, 232]
    tip_canchatenis = [233, 234]
    tip_toboganes = [235, 236, 237, 238]
    tip_marquesinas = [239, 240, 241, 242]
    tip_estadios = [243, 244, 245]
    tip_plazatoros = [246, 247]
    tip_viaferrea = [248, 249]
    tip_carreteras = [250, 251]
    tip_cimientos = [252, 253, 254, 255]
    tip_estr_aerop = [256, 257, 258]
    tip_lagunasoxi = [259]

    m = []
    for i in lt:
        i = list(i)
        if i[1] == 346 and i[3] not in tip_albercas:
            i.append('042_Las unidades no convencionales con uso albercas, deben calificarse con tipo_anexo albercas')
            m.append(i)
        elif i[1] == 347 and i[3] not in tip_beneficiaderos:
            i.append(
                '042_Las unidades no convencionales con uso beneficiadero, deben calificarse con tipo_anexo beneficiadero')
            m.append(i)
        elif i[1] == 350 and i[3] not in tip_canchatenis:
            i.append(
                '042_Las unidades no convencionales con uso cancha de tenis, deben calificarse con tipo_anexo cancha de tenis')
            m.append(i)
        elif i[1] == 351 and i[3] not in tip_carreteras:
            i.append(
                '042_Las unidades no convencionales con uso carretera, deben calificarse con tipo_anexo cancha de carretera')
            m.append(i)
        elif i[1] == 353 and i[3] not in tip_cimientos:
            i.append('042_Las unidades no convencionales con uso cimientos, deben calificarse con tipo_anexo cimientos')
            m.append(i)
        elif i[1] == 354 and i[3] not in tip_cocheras:
            i.append('042_Las unidades no convencionales con uso cocheras, deben calificarse con tipo_anexo cocheras')
            m.append(i)
        elif i[1] == 357 and i[3] not in tip_corrales:
            i.append('042_Las unidades no convencionales con uso corrares, deben calificarse con tipo_anexo corrares')
            m.append(i)
        elif i[1] == 358 and i[3] not in tip_establos:
            i.append('042_Las unidades no convencionales con uso establos, deben calificarse con tipo_anexo establos')
            m.append(i)
        elif i[1] == 361 and i[3] not in tip_galpones:
            i.append('042_Las unidades no convencionales con uso galpones, deben calificarse con tipo_anexo galpones')
            m.append(i)
        elif i[1] == 363 and i[3] not in tip_kioscos:
            i.append('042_Las unidades no convencionales con uso kioscos, deben calificarse con tipo_anexo kioscos')
            m.append(i)
        elif i[1] == 364 and i[3] not in tip_lagunasoxi:
            i.append(
                '042_Las unidades no convencionales con uso lagunas oxidacion, deben calificarse con tipo_anexo lagunas oxidacion')
            m.append(i)
        elif i[1] == 365 and i[3] not in tip_marquesinas:
            i.append(
                '042_Las unidades no convencionales con uso marquesinas, deben calificarse con tipo_anexo marquesinas')
            m.append(i)
        elif i[1] == 366 and i[3] not in tip_muelles:
            i.append('042_Las unidades no convencionales con uso muelles, deben calificarse con tipo_anexo muelles')
            m.append(i)
        elif i[1] == 369 and i[3] not in tip_piscinas:
            i.append('042_Las unidades no convencionales con uso piscinas, deben calificarse con tipo_anexo piscinas')
            m.append(i)
        elif i[1] == 370 and i[3] not in tip_estr_aerop:
            i.append(
                '042_Las unidades no convencionales con uso pista aeropuerto, deben calificarse con tipo_anexo estruc. aeroportuaria')
            m.append(i)
        elif i[1] == 371 and i[3] not in tip_pozos:
            i.append('042_Las unidades no convencionales con uso pozos, deben calificarse con tipo_anexo pozos')
            m.append(i)
        elif i[1] == 372 and i[3] not in tip_enrramadas:
            i.append('042_Las unidades no convencionales con uso ramada, deben calificarse con tipo_anexo ramada')
            m.append(i)
        elif i[1] == 373 and i[3] not in tip_secaderos:
            i.append('042_Las unidades no convencionales con uso secadero, deben calificarse con tipo_anexo secadero')
            m.append(i)
        elif i[1] == 374 and i[3] not in tip_silos:
            i.append('042_Las unidades no convencionales con uso silos, deben calificarse con tipo_anexo silos')
            m.append(i)
        elif i[1] == 375 and i[3] not in tip_tanques:
            i.append('042_Las unidades no convencionales con uso tanques, deben calificarse con tipo_anexo tanques')
            m.append(i)
        elif i[1] == 376 and i[3] not in tip_toboganes:
            i.append('042_Las unidades no convencionales con uso toboganes, deben calificarse con tipo_anexo toboganes')
            m.append(i)
        elif i[1] == 378 and i[3] not in tip_torres:
            i.append(
                '042_Las unidades no convencionales con uso torres enfriamiento, deben calificarse con tipo_anexo torres enfriamiento')
            m.append(i)
        elif i[1] == 380 and i[3] not in tip_viaferrea:
            i.append(
                '042_Las unidades no convencionales con uso via ferrea, deben calificarse con tipo_anexo via ferrea')
            m.append(i)

    try:
        if len(m) != 0:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n043_para UC NO Convencionales las calificaciones deben ser consistentes con el uso de la UC\n")
            excel(m, '043_para UC NO Convencionales las calificaciones deben ser consistentes con el uso de la UC', 'lc_caracteristicasunidadconstruccion, lc_calificacionnoconvencional', '043', ruta)
        else:
            print(f"Se presentaron _{len(m)}_ inconsistencias del tipo:\n043_para UC NO Convencionales las calificaciones deben ser consistentes con el uso de la UC\n")
    except Exception as e:
        print(f"No se pudo generar el archivo Excel con el reporte,\n"\
              f"revise que no tenga abierto un archivo .xlsx con el mismo nombre de la validacion\n"\
              f"y que tenga instalada la libreria xlsxwriter de python\n{e}")



