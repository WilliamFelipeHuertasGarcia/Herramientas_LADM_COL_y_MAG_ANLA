"""
CampoMAG fue desarrollado por:

William Huertas – wfhuertasg@gmail.com
Linda Maldonado - lkmaldonadoo999@gmail.com
"""

from PyQt5.QtWidgets import QFileDialog
import subprocess
import os


def gpkg(hostt, puerto, usuario, contra, nombre_db):

    # Configura el diálogo de selección de archivo
    file_dialog = QFileDialog()
    file_dialog.setAcceptMode(QFileDialog.AcceptSave)
    file_dialog.setDefaultSuffix('gpkg')

    # Abre el diálogo y obtén la ruta del archivo
    file_path, _ = file_dialog.getSaveFileName(None, "Guardar", "", "GeoPackage (*.gpkg);;Todos los archivos (*.*)")

    # Verifica si el usuario hizo clic en Guardar
    if file_path:
        # Ahora puedes utilizar 'file_path' según tus necesidades
        print(f"Ruta del archivo seleccionado: {file_path}")
        print(f"host: {hostt}\n usuario: {usuario}\n BD: {nombre_db}\n contraseña: {contra}\n puerto: {puerto}")

        cmd = ['ogr2ogr',
               '-f', 'GPKG',
               f'{file_path}',
               f'PG:host={hostt} user={usuario} dbname={nombre_db} password={contra} port={puerto}'
               ]

        result = subprocess.run(cmd, capture_output=True)

        print(result.stdout.decode())
        print(result.stderr.decode())
    else:
        print("Operación cancelada por el usuario.")

